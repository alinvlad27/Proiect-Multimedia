// VLAD ALIN
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')

// ajusteaza dimensiunile canvas-ului pentru a se potrivi cu dimensiunile ferestrei
canvas.width = window.innerWidth
canvas.height = window.innerHeight

// asteroizii
class Asteroid {
    constructor({ position, acceleration, radius }) {
      this.position = position // pozitia initiala a asteroidului
      this.acceleration = acceleration // viteza asteroidului
      this.radius = radius // raza asteroidului
      this.racheteNecesare = Math.floor(Math.random() * 4) + 1;  // numarul aleatoriu de rachete necesare pentru distrugere
    }
  
    // desenarea asteroidului si actualizarea lui in functie de viteza
    update() {
      ctx.beginPath()
      ctx.arc(this.position.x, this.position.y, this.radius, 0, Math.PI * 2, false)

      // selecteaza culoarea in functie de numarul de rachete necesare
      switch (this.racheteNecesare) {
          case 1:
            ctx.strokeStyle = 'green';
            break;
          case 2:
            ctx.strokeStyle = 'yellow';
            break;
          case 3:
            ctx.strokeStyle = 'orange';
            break;
          case 4:
            ctx.strokeStyle = 'red';
            break;
          default:
            ctx.strokeStyle = 'white';
            break;
        }
      ctx.stroke()
  
      // afiseaza numarul de rachete necesare in interiorul asteroidului
      ctx.fillStyle = 'white';
      ctx.font = '16px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(this.racheteNecesare.toString(), this.position.x, this.position.y + 4);
  
      // actualizeaza pozitia
      this.position.x += this.acceleration.x
      this.position.y += this.acceleration.y
  
    }
  
    // gestionarea impactului cu o racheta
    lovesteCuRacheta() {
      this.racheteNecesare--;
    }
  }

// utilizatorul / nava jucatorului
class Utilizator {
  constructor({ position, acceleration }) { // pozitia si viteza navei
    this.position = position  // pozitia initiala a navei
    this.acceleration = acceleration  // viteza navei
    this.rotation = 0;  // unghiul de rotatie al navei
    this.numarVieti = 3;  // numarul de vieti ale navei
    this.puncte = 0;   // punctajul acumulat de nava
  }

  // deseneaza nava si actualizeaza pozitia in functie de viteaza
update() {
    ctx.save()
  
    ctx.translate(this.position.x, this.position.y)
    ctx.rotate(this.rotation)
  
    ctx.beginPath()
    ctx.moveTo(15, 0)
    ctx.lineTo(-15, 10)
    ctx.lineTo(-15, -10)
    ctx.closePath()
  
    ctx.strokeStyle = 'white'
    ctx.fillStyle = 'gray'
    ctx.fill()
    ctx.stroke()
  
    ctx.restore()

    // actualizare
    this.position.x += this.acceleration.x
    this.position.y += this.acceleration.y
  }

   // returneaza un array cu varfurile navei
getCoordonateNava() {
    // calculul valorilor cosinus si sinus ale unghiului de rotatie al navei
    const cos = Math.cos(this.rotation);
    const sin = Math.sin(this.rotation);

    // calculul coordonatelor varfurilor navei in functie de rotatie si pozitie
    const point1 = {x: this.position.x + cos * 30 - sin * 0, y: this.position.y + sin * 30 + cos * 0};
    const point2 = {x: this.position.x + cos * -20 - sin * 20, y: this.position.y + sin * -20 + cos * 20};
    const point3 = {x: this.position.x + cos * -20 - sin * -20, y: this.position.y + sin * -20 + cos * -20};
  
    return [point1, point2, point3];
  }

  // detectarea coliziunii cu asteroidul si gestionarea numarului de vieti
  lovesteCuAsteroid(asteroid) {
    const diferentaX = asteroid.position.x - this.position.x;
    const diferentaY = asteroid.position.y - this.position.y;
    const distance = Math.sqrt(diferentaX * diferentaX + diferentaY * diferentaY);
  
    // verifica daca distanta este mai mica sau egala cu suma razelor navei si asteroidului
    if (distance <= asteroid.radius) {
      this.numarVieti--; 
  
      if (this.numarVieti <= 0) {
        window.cancelAnimationFrame(animationId);
         // opreste intervalul pentru generarea asteroidilor
        clearInterval(asteroiziInterval);
      } else {
        // repozitioneaza nava in centrul canvas-ului
        this.position = { x: canvas.width / 2, y: canvas.height / 2 };
        // resetarea vitezei navei
        this.acceleration = { x: 0, y: 0 };
      }
    }
  }

   // actualizarea si afisarea punctelor
   updatePuncte(puncteNoi) {
    this.puncte += puncteNoi;
     if (this.puncte >= 100) {
        this.numarVieti++; 
        this.puncte -= 100; 
      }
  }

  // desenarea punctelor
  deseneazaPuncte() {
    ctx.fillStyle = 'white';
    ctx.font = '20px Arial';
    ctx.textAlign = 'right';
    ctx.fillText('Puncte: ' + this.puncte, canvas.width - 20, 30);
  }

}

// rachetele navei lansate de utilizator
class Racheta {
  constructor({ position, acceleration }) {
    this.position = position // pozitia initiala a rachetei
    this.acceleration = acceleration // viteza rachetei
    this.radius = 2 // raza rachetei pentru desenare
  }

  //desenarea proiectilului si actualizarea lui in functie de viteza
  update() {
    ctx.beginPath();
    ctx.arc(this.position.x, this.position.y, this.radius, 0, Math.PI * 2, false);
    ctx.fillStyle = 'red';
    ctx.fill();
    ctx.stroke();  
    ctx.closePath();

    // actualizeaza pozitia rachetei
    this.position.x += this.acceleration.x
    this.position.y += this.acceleration.y
  }

}

const SPEED = 1.5 // viteza de deplasare a navei
const ROTATIONAL_SPEED = 0.04 // viteza de rotatie a navei
const FRICTION = 0.97 // franeaza treptat dupa ce tasta de deplasare inainte este eliberata
const Racheta_SPEED = 3 // viteaza rachetelor
const Rachete = [] // stocheaza rachetele navei
const asteroids = [] // stocheaza asteroizii

// creeaza asteroizi la intervale regulate de timp
const asteroiziInterval = window.setInterval(() => {

// numarul de asteroizi generat in fiecare interval
const numarAsteroizi = 4;

for (let i = 0; i < numarAsteroizi; i++) {
    // genereaza un numar aleatoriu pentru a determina de pe ce latura a ecranului va aparea asteroidul
  const side = Math.floor(Math.random() * 4);
    // genereaza un radius aleatoriu pentru asteroid
  const radius = 50 * Math.random() + 10;
  
  let x, y, vx, vy;

   // determina pozitia si viteza asteroidului in functie de latura ecranului
  switch (side) {
    // stanga ecranului
    case 0: 
      x = 0 - radius; y = Math.random() * canvas.height; vx = 1; vy = 0; break;
    case 1: 
    // partea de jos a ecranului
      x = Math.random() * canvas.width; y = canvas.height + radius; vx = 0; vy = -1; break;
    case 2:
    // dreapta ecranului
      x = canvas.width + radius; y = Math.random() * canvas.height; vx = -1; vy = 0; break;
    case 3:
    // partea de sus a ecranului
      x = Math.random() * canvas.width; y = 0 - radius; vx = 0; vy = 1; break;
  }

// adauga asteroidul nou generat in array-ul de asteroizi
 asteroids.push(
    new Asteroid({
      position: { x, y },
      acceleration: { x: vx, y: vy },
      radius,
    })
  );
}
}, 3000)

// verifica coliziunea intre asteroid si racheta navei
function coliziuneAsteroidRacheta(asteroid, racheta) {
    // calculeaza distanta euclidiană intre centrul asteroidului si centrul rachetei folosind teorema lui Pitagora
    const distanta = Math.hypot(racheta.position.x - asteroid.position.x, racheta.position.y - asteroid.position.y);

    // verifica daca distanta este mai mica sau egala cu suma razelor asteroidului si rachetei
    return distanta <= asteroid.radius + racheta.radius;
}

// verifica coliziunea dintre asteroid si nava
function coliziuneAsteroidNava(asteroid, nava) {
  for (let i = 0; i < 3; i++) {
    // defineste punctul de inceput si punctul de sfarsit al fiecarei laturi a navei
    let start = nava[i]
    let end = nava[(i + 1) % 3]

    // verifica daca pozitia asteroidului se afla pe linia dintre punctele de început si sfarsit ale laturii
    if (verificaPunct(asteroid.position.x, asteroid.position.y, start, end)) {
      // calculeaza distanta intre pozitia asteroidului si linia navei
      let dx = asteroid.position.x - start.x
      let dy = asteroid.position.y - start.y
      let distance = Math.sqrt(dx * dx + dy * dy)

      // verifica daca asteroidul este suficient de aproape de linia navei pentru a considera o coliziune
      if (distance <= asteroid.radius) {
        return true
      }
    }
  }
  // nu exista coliziune
  return false
}

// detectia coliziunilor intre obiecte in spatiul bidimensional
function verificaPunct(x, y, start, end) {
    // verifica daca coordonata x/y a punctului este intre coordonatele x/y ale punctelor de început si sfarsit ale liniei
    const esteXpeLimita = x >= Math.min(start.x, end.x) && x <= Math.max(start.x, end.x)
    const esteYpeLimitas = y >= Math.min(start.y, end.y) && y <= Math.max(start.y, end.y)

    return esteXpeLimita && esteYpeLimitas
}

// se creeaza o noua instanta a clasei Utilizator
const utilizator = new Utilizator({
     // pozitia initiala in centrul canvas-ului
    position: { x: canvas.width / 2, y: canvas.height / 2 },
    // viteza initiala zero
    acceleration: { x: 0, y: 0 },
  })
  
  // gestionarea tastelor 
  const keys = {
    sageataSus: {
      pressed: false,
    },
    sageataStanga: {
      pressed: false,
    },
    sageataDreapta: {
      pressed: false,
    },
    z: {
      pressed: false,
    },
    c: {
      pressed: false,
    },
  }

// animatia jocului
function animatie() {
  // pentru a putea opri animatia in viitor
  const animationId = window.requestAnimationFrame(animatie)

  ctx.fillStyle = 'black'
  ctx.fillRect(0, 0, canvas.width, canvas.height)

  // deseneaza numarul de vieti
  ctx.fillStyle = 'white';
  ctx.font = '20px Arial';
  ctx.textAlign = 'left';
  ctx.fillText('Vieți rămase : ' + utilizator.numarVieti, 20, 30);

  // deseneaza GAME OVER la finalul jocului
  if (utilizator.numarVieti <= 0) {
    ctx.fillStyle = 'white';
    ctx.textBaseline = "middle";
    ctx.textAlign = 'center';
    ctx.font = '40px Arial';
    ctx.fillText('GAME OVER', canvas.width / 2 - 100, canvas.height / 2);

    // opreste animatia si intervalul de generare a asteroizilor
    window.cancelAnimationFrame(animationId);
    clearInterval(asteroiziInterval);
  }

  utilizator.update();
  utilizator.deseneazaPuncte(); 

  // actualizeaza si deseneaza rachetele navei
  for (let i = Rachete.length - 1; i >= 0; i--) {
    const Racheta = Rachete[i]
    Racheta.update()

    // se elimina rachtele care au iesit in afara canvas-ului
    if (
      Racheta.position.x + Racheta.radius < 0 ||
      Racheta.position.x - Racheta.radius > canvas.width ||
      Racheta.position.y - Racheta.radius > canvas.height ||
      Racheta.position.y + Racheta.radius < 0
    ) {
        // elimina racheta din array
      Rachete.splice(i, 1)
    }
  }

  // actualizeaza si deseneaza asteroizii
  for (let i = asteroids.length - 1; i >= 0; i--) {
    const asteroid = asteroids[i]
    asteroid.update()

    // verifica coliziunea intre nava utilizatorului si asteroizi
    if (coliziuneAsteroidNava(asteroid, utilizator.getCoordonateNava
())) {
        utilizator.lovesteCuAsteroid(asteroid); 
    }

    // se elimina asteroizii care au iesit in afara canvas-ului
    if (
      asteroid.position.x + asteroid.radius < 0 ||
      asteroid.position.x - asteroid.radius > canvas.width ||
      asteroid.position.y - asteroid.radius > canvas.height ||
      asteroid.position.y + asteroid.radius < 0
    ) {
         // elimina asteroidul din array
      asteroids.splice(i, 1)
    }

    // verifica coliziunea intre asteroizi si rachetele navei
    for (let j = Rachete.length - 1; j >= 0; j--) {
      const Racheta = Rachete[j]

      if (coliziuneAsteroidRacheta(asteroid, Racheta)) {
        // actualizeaza numarul de rachete necesare la impact
        asteroid.lovesteCuRacheta(); 

        // verifica numarul de rachete necesare si actualizeaza punctele
        if (asteroid.racheteNecesare === 0) {
          if (asteroid.radius > 30) {
            utilizator.updatePuncte(40);
          } else {
            utilizator.updatePuncte(20);
          }
          // elimina asteroidul
          asteroids.splice(i, 1);
        }
        // elimina proiectilul
        Rachete.splice(j, 1);
      }
    }
  }

  // controleaza miscarea si rotatia navei 
  if (keys.sageataSus.pressed) {
     // aplica acceleratia in directia de deplasare a navei
    utilizator.acceleration.x = Math.cos(utilizator.rotation) * SPEED
    utilizator.acceleration.y = Math.sin(utilizator.rotation) * SPEED
  } else if (!keys.sageataSus.pressed) {
    // aplica frecarea daca tasta de deplasare inainte nu este apasata
    utilizator.acceleration.x *= FRICTION
    utilizator.acceleration.y *= FRICTION
  }

  // controleaza rotatia navei in functie de tastele de directie si rotatie
  if (keys.sageataDreapta.pressed) utilizator.rotation += ROTATIONAL_SPEED
  else if (keys.sageataStanga.pressed) utilizator.rotation -= ROTATIONAL_SPEED

  // controleaza rotatia navei in functie de tastele 'c' și 'z'
  if (keys.c.pressed) utilizator.rotation += ROTATIONAL_SPEED
  else if (keys.z.pressed) utilizator.rotation -= ROTATIONAL_SPEED
}
animatie()

const RACHETE_MAXIME = 3; // nr de rachete lansate simultan
const COOLDOWN = 500; // timpul de asteptare intre rachete
let ultimaLansareRacheta = 0; 

// gestionarea evenimentelor de apasare a tastelor
window.addEventListener('keydown', (event) => {
    // timestamp-ul curent
    const acum = Date.now(); 

    // verificarea codului tastei apasate si setarea starii corespunzătoare
  switch (event.code) {
    case 'ArrowUp':
      keys.sageataSus.pressed = true // tasta sageata sus apasata
      break
    case 'ArrowLeft':
      keys.sageataStanga.pressed = true // tasta sageata stanga apasata
      break
    case 'ArrowRight':
      keys.sageataDreapta.pressed = true // tasta sageata dreapta apasata
      break
    case 'KeyZ':
      keys.z.pressed = true // tasta 'z' apasata
      break
    case 'KeyC':
      keys.c.pressed = true // tasta 'c' apasata
      break
    case 'KeyX':
         // verificarea timpului scurs intre lansarile de rachete pentru a respecta cooldown-ul
     if (acum - ultimaLansareRacheta >= COOLDOWN) {
        // verificarea numarului maxim de rachete si adaugarea unei rachete noi
        if (Rachete.length < RACHETE_MAXIME) {
      Rachete.push(
        new Racheta({
          position: {
            x: utilizator.position.x + Math.cos(utilizator.rotation) * 30,
            y: utilizator.position.y + Math.sin(utilizator.rotation) * 30,
          },
          acceleration: {
            x: Math.cos(utilizator.rotation) * Racheta_SPEED,
            y: Math.sin(utilizator.rotation) * Racheta_SPEED,
          },
        })
      );
      // actualizarea timpului ultimei lansari de racheta
      ultimaLansareRacheta = acum; 
    }
}
      break
  }
})

// gestionarea evenimentelor de eliberare a tastelor
window.addEventListener('keyup', (event) => {
  switch (event.code) {
    case 'ArrowUp':
      keys.sageataSus.pressed = false
      break
    case 'ArrowLeft':
      keys.sageataStanga.pressed = false
      break
    case 'ArrowRight':
      keys.sageataDreapta.pressed = false
      break
    case 'KeyZ':
      keys.z.pressed = false
      break
    case 'KeyC':
      keys.c.pressed = false
      break
  }
})
